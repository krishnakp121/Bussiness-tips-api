#!/usr/bin/env node
// Wrapper to keep the server running

require('./index.js');

// Keep the process alive
setInterval(() => {
  // No-op: just keep process running
}, 60000);
