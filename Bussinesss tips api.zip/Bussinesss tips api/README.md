# Daily Ideas / Business Tips API

Small Node.js + Express API that returns a random business or productivity tip from a JSON file.

Features
- Single endpoint: GET /daily-tip
- Returns JSON: { "tip": "Your tip here." }
- Loads 110 tips from `tips.json`
- CORS enabled so it can be used from web or mobile apps

Getting started (Windows PowerShell)

1. Install dependencies

```powershell
cd "C:/Users/LENOVO/Desktop/Bussinesss tips api"
npm install
```

2. Run the API

```powershell
npm start
# The server will listen on port 3000 by default. Visit http://localhost:3000/daily-tip
```

3. Example request

```powershell
# Using curl
curl http://localhost:3000/daily-tip

# Example response
#{ "tip": "Start your day by listing the top 3 tasks that will move the needle." }
```

Deploying to Replit
- Replit will run `npm start` by default. This repo includes a `.replit` file to instruct Replit to run `npm start`.

Deploying to Render
1. Push this repo to GitHub
2. Go to [render.com](https://render.com) and create a new Web Service
3. Connect your GitHub repo
4. Render will automatically use `render.yaml` to configure the build and start commands
5. The service will start and be available at `https://<your-service-name>.onrender.com/daily-tip`

Notes
- The server loads the tips once at startup. To update tips, edit `tips.json` and restart the server.
- You can change the port by setting the PORT environment variable.
