// Daily Ideas / Business Tips API
// A very small Express server that returns a random tip from tips.json

const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Enable CORS so this API can be called from browsers or mobile apps.
app.use(cors());

// Load tips from JSON file at startup to avoid re-reading file on every request.
// If the file fails to load, we log and exit since the API cannot function without tips.
const tipsPath = path.join(__dirname, 'tips.json');
let tips = [];
try {
  const raw = fs.readFileSync(tipsPath, 'utf8');
  tips = JSON.parse(raw);
  if (!Array.isArray(tips) || tips.length === 0) {
    console.error('tips.json must contain a non-empty array of tip strings');
    process.exit(1);
  }
} catch (err) {
  console.error('Failed to load tips.json:', err.message);
  process.exit(1);
}

// Helper: pick a random element from the tips array
function getRandomTip() {
  const idx = Math.floor(Math.random() * tips.length);
  return tips[idx];
}

// GET /daily-tip
// Returns a random tip in the JSON shape: { "tip": "Your tip here." }
app.get('/daily-tip', (req, res) => {
  const tip = getRandomTip();
  res.json({ tip });
});

// Root path: quick health check
app.get('/', (req, res) => {
  res.json({ status: 'ok', tipsAvailable: tips.length });
});

// Start server and keep it running
const server = app.listen(PORT, () => {
  console.log(`Daily Ideas API listening on port ${PORT} — ${tips.length} tips loaded`);
});

// Graceful error handling
server.on('error', (err) => {
  console.error('Server error:', err);
  process.exit(1);
});
